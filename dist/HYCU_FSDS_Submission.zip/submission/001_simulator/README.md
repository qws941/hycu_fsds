# FSDS Simulator Setup (Windows)

## 설치
1. `settings.json`을 복사: `C:\Users\<사용자>\Documents\AirSim\settings.json`
2. FSDS 시뮬레이터 실행

## 설정값
- `LocalHostIp`: `0.0.0.0` (모든 인터페이스)
- `ApiServerPort`: `41451`

## 방화벽
Windows Defender 방화벽 > 고급 설정 > 인바운드 규칙 > 새 규칙 > 포트 > 41451
